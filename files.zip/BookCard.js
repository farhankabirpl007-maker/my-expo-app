import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now - d;
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function BookCard({ book, theme, onPress }) {
  const progress = book.progress || 0;
  const s = styles(theme);

  return (
    <TouchableOpacity style={s.card} onPress={onPress} activeOpacity={0.8}>
      {/* Book spine / cover */}
      <View style={[s.spine, { backgroundColor: book.color || theme.accent }]}>
        <Text style={s.spineText} numberOfLines={4}>
          {book.title}
        </Text>
      </View>

      {/* Book info */}
      <View style={s.info}>
        <Text style={s.title} numberOfLines={2}>{book.title}</Text>

        <View style={s.meta}>
          <Text style={s.metaText}>{book.totalPages} pages</Text>
          <Text style={s.dot}>·</Text>
          <Text style={s.metaText}>{formatDate(book.lastOpened)}</Text>
        </View>

        {/* Progress bar */}
        <View style={s.progressRow}>
          <View style={s.progressTrack}>
            <View style={[s.progressFill, { width: `${progress}%`, backgroundColor: book.color || theme.accent }]} />
          </View>
          <Text style={s.progressLabel}>{progress}%</Text>
        </View>

        <Text style={s.resumeText}>
          {progress === 0 ? 'Start reading →' : progress === 100 ? 'Completed ✓' : `Resume on p. ${(book.currentPage || 0) + 1} →`}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = (theme) => StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: theme.card,
    borderRadius: 16,
    marginBottom: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: theme.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
  },
  spine: {
    width: 72,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  spineText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 11,
    fontFamily: 'Georgia',
    textAlign: 'center',
    fontWeight: '600',
    lineHeight: 15,
    transform: [{ rotate: '0deg' }],
  },
  info: {
    flex: 1,
    padding: 14,
    justifyContent: 'space-between',
    gap: 6,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: theme.text,
    fontFamily: 'Georgia',
    lineHeight: 22,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    color: theme.textSecondary,
  },
  dot: {
    color: theme.textSecondary,
    fontSize: 12,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  progressTrack: {
    flex: 1,
    height: 4,
    backgroundColor: theme.border,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressLabel: {
    fontSize: 12,
    color: theme.textSecondary,
    fontWeight: '600',
    width: 32,
    textAlign: 'right',
  },
  resumeText: {
    fontSize: 12,
    color: theme.accent,
    fontWeight: '600',
  },
});
