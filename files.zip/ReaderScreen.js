import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, TouchableOpacity,
  ScrollView, Animated, Alert, PanResponder, Dimensions,
} from 'react-native';
import * as Speech from 'expo-speech';

import { useAppContext } from '../context/AppContext';
import TTSControls from '../components/TTSControls';
import WaveformAnimation from '../components/WaveformAnimation';
import SentenceHighlighter from '../components/SentenceHighlighter';
import { splitIntoSentences } from '../utils/textSplitter';
import { updateBookProgress, saveBookmark, getBookmarks } from '../utils/storage';
import { getBooks } from '../utils/storage';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function ReaderScreen({ navigation, route }) {
  const { theme, fontSize, fontFamily, settings, books, setBooks, setBookmarks } = useAppContext();

  const [book, setBook] = useState(route.params?.book);
  const [currentPage, setCurrentPage] = useState(book?.currentPage || 0);
  const [isListenMode, setIsListenMode] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSentenceIndex, setCurrentSentenceIndex] = useState(-1);
  const [ttsSpeed, setTtsSpeed] = useState(settings.ttsSpeed || 1.0);
  const [fontSize_local, setFontSize_local] = useState(fontSize);

  const slideAnim = useRef(new Animated.Value(0)).current;
  const scrollRef = useRef(null);
  const sentencesRef = useRef([]);
  const sentenceIndexRef = useRef(0);
  const isPlayingRef = useRef(false);

  const pages = book?.pages || [];
  const totalPages = pages.length;
  const currentPageData = pages[currentPage];
  const pageContent = currentPageData?.content || '';

  // Update sentences when page changes
  useEffect(() => {
    sentencesRef.current = splitIntoSentences(pageContent);
  }, [pageContent]);

  // Stop TTS when leaving
  useEffect(() => {
    return () => {
      Speech.stop();
    };
  }, []);

  // Save progress when page changes
  useEffect(() => {
    if (book) {
      updateBookProgress(book.id, currentPage).then(updatedBooks => {
        setBooks(updatedBooks);
      });
    }
  }, [currentPage]);

  // ── Navigation ─────────────────────────────────────────
  const animatePage = useCallback((direction, callback) => {
    const toValue = direction === 'left' ? -SCREEN_WIDTH : SCREEN_WIDTH;
    Animated.sequence([
      Animated.timing(slideAnim, {
        toValue,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      slideAnim.setValue(-toValue);
      callback();
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true,
      }).start();
    });
  }, []);

  const goToPage = useCallback((newPage, direction = 'left') => {
    if (newPage < 0 || newPage >= totalPages) return;
    Speech.stop();
    setIsPlaying(false);
    isPlayingRef.current = false;
    setCurrentSentenceIndex(-1);
    animatePage(direction, () => {
      setCurrentPage(newPage);
      scrollRef.current?.scrollTo({ y: 0, animated: false });
    });
  }, [totalPages, animatePage]);

  const nextPage = () => goToPage(currentPage + 1, 'left');
  const prevPage = () => goToPage(currentPage - 1, 'right');

  // ── Swipe Gesture ───────────────────────────────────────
  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > Math.abs(g.dy) && Math.abs(g.dx) > 20,
      onPanResponderRelease: (_, g) => {
        if (g.dx < -60) nextPage();
        else if (g.dx > 60) prevPage();
      },
    })
  ).current;

  // ── TTS ─────────────────────────────────────────────────
  const speakSentence = useCallback((index) => {
    const sentences = sentencesRef.current;
    if (index >= sentences.length) {
      // Auto advance to next page
      setIsPlaying(false);
      isPlayingRef.current = false;
      setCurrentSentenceIndex(-1);
      setTimeout(() => {
        if (currentPage + 1 < totalPages) {
          goToPage(currentPage + 1, 'left');
          setTimeout(() => startPlayback(0), 400);
        }
      }, 500);
      return;
    }

    setCurrentSentenceIndex(index);
    sentenceIndexRef.current = index;

    Speech.speak(sentences[index], {
      rate: ttsSpeed,
      onDone: () => {
        if (isPlayingRef.current) {
          speakSentence(sentenceIndexRef.current + 1);
        }
      },
      onError: () => {
        setIsPlaying(false);
        isPlayingRef.current = false;
      },
    });
  }, [ttsSpeed, currentPage, totalPages]);

  const startPlayback = useCallback((fromIndex = 0) => {
    Speech.stop();
    isPlayingRef.current = true;
    setIsPlaying(true);
    speakSentence(fromIndex);
  }, [speakSentence]);

  const pausePlayback = useCallback(() => {
    Speech.stop();
    isPlayingRef.current = false;
    setIsPlaying(false);
  }, []);

  const handlePlayPause = () => {
    if (isPlaying) {
      pausePlayback();
    } else {
      const fromIdx = currentSentenceIndex >= 0 ? currentSentenceIndex : 0;
      startPlayback(fromIdx);
    }
  };

  const handlePrevSentence = () => {
    const newIdx = Math.max(0, currentSentenceIndex - 1);
    pausePlayback();
    setCurrentSentenceIndex(newIdx);
    if (isListenMode) startPlayback(newIdx);
  };

  const handleNextSentence = () => {
    const sentences = sentencesRef.current;
    const newIdx = Math.min(sentences.length - 1, currentSentenceIndex + 1);
    pausePlayback();
    setCurrentSentenceIndex(newIdx);
    if (isListenMode) startPlayback(newIdx);
  };

  const handleSpeedChange = (speed) => {
    setTtsSpeed(speed);
    if (isPlaying) {
      const idx = sentenceIndexRef.current;
      pausePlayback();
      setTimeout(() => startPlayback(idx), 100);
    }
  };

  const toggleListenMode = () => {
    if (isListenMode) {
      pausePlayback();
      setCurrentSentenceIndex(-1);
    }
    setIsListenMode(!isListenMode);
  };

  // ── Bookmarking ─────────────────────────────────────────
  const handleBookmark = async () => {
    const snippet = pageContent.slice(0, 120) + '…';
    const bookmark = {
      id: Math.random().toString(36).substr(2, 9),
      bookId: book.id,
      bookTitle: book.title,
      pageNumber: currentPage,
      text: snippet,
      createdAt: new Date().toISOString(),
    };
    const updated = await saveBookmark(bookmark);
    setBookmarks(updated);
    Alert.alert('Bookmarked!', 'Page saved to your bookmarks.');
  };

  const toggleFontSize = () => {
    const sizes = [16, 18, 20];
    const idx = sizes.indexOf(fontSize_local);
    setFontSize_local(sizes[(idx + 1) % sizes.length]);
  };

  const s = styles(theme, fontSize_local, fontFamily);
  const chapterTitle = currentPageData?.chapterTitle || '';

  return (
    <SafeAreaView style={s.safe}>
      {/* Top Bar */}
      <View style={s.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.topBtn}>
          <Text style={s.topBtnText}>←</Text>
        </TouchableOpacity>
        <View style={s.titleContainer}>
          <Text style={s.bookTitle} numberOfLines={1}>{book?.title}</Text>
          {chapterTitle ? (
            <Text style={s.chapterTitle} numberOfLines={1}>{chapterTitle}</Text>
          ) : null}
        </View>
        <TouchableOpacity onPress={toggleFontSize} style={s.topBtn}>
          <Text style={s.topBtnText}>Aa</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleBookmark} style={s.topBtn}>
          <Text style={s.topBtnText}>🔖</Text>
        </TouchableOpacity>
      </View>

      {/* Page Content */}
      <Animated.View
        style={[s.pageWrapper, { transform: [{ translateX: slideAnim }] }]}
        {...panResponder.panHandlers}
      >
        <ScrollView
          ref={scrollRef}
          style={s.scroll}
          contentContainerStyle={s.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {isListenMode ? (
            <SentenceHighlighter
              sentences={sentencesRef.current}
              currentIndex={currentSentenceIndex}
              theme={theme}
              fontSize={fontSize_local}
              fontFamily={fontFamily}
            />
          ) : (
            <Text style={s.pageText}>{pageContent}</Text>
          )}
        </ScrollView>
      </Animated.View>

      {/* Listen Mode Overlay */}
      {isListenMode && (
        <View style={s.listenBar}>
          <WaveformAnimation isPlaying={isPlaying} theme={theme} />
          <TTSControls
            isPlaying={isPlaying}
            speed={ttsSpeed}
            onPlayPause={handlePlayPause}
            onPrev={handlePrevSentence}
            onNext={handleNextSentence}
            onSpeedChange={handleSpeedChange}
            theme={theme}
          />
        </View>
      )}

      {/* Bottom Bar */}
      <View style={s.bottomBar}>
        <TouchableOpacity onPress={prevPage} disabled={currentPage === 0} style={s.pageBtn}>
          <Text style={[s.pageBtnText, currentPage === 0 && s.disabled]}>‹</Text>
        </TouchableOpacity>

        <View style={s.progressSection}>
          <Text style={s.pageLabel}>
            {currentPage + 1} / {totalPages}
          </Text>
          <View style={s.progressTrack}>
            <View
              style={[s.progressFill, { width: `${((currentPage + 1) / totalPages) * 100}%` }]}
            />
          </View>
        </View>

        <TouchableOpacity onPress={nextPage} disabled={currentPage === totalPages - 1} style={s.pageBtn}>
          <Text style={[s.pageBtnText, currentPage === totalPages - 1 && s.disabled]}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={toggleListenMode}
          style={[s.listenBtn, isListenMode && s.listenBtnActive]}
        >
          <Text style={s.listenBtnText}>{isListenMode ? '📖 Read' : '🎧 Listen'}</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = (theme, fontSize, fontFamily) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.background },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
    backgroundColor: theme.surface,
  },
  topBtn: {
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  topBtnText: {
    fontSize: 20,
    color: theme.text,
  },
  titleContainer: {
    flex: 1,
    paddingHorizontal: 8,
  },
  bookTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.text,
    fontFamily,
  },
  chapterTitle: {
    fontSize: 12,
    color: theme.textSecondary,
    marginTop: 1,
  },
  pageWrapper: {
    flex: 1,
  },
  scroll: { flex: 1 },
  scrollContent: {
    padding: 24,
    paddingBottom: 40,
  },
  pageText: {
    fontSize,
    color: theme.text,
    fontFamily: fontFamily === 'Georgia' ? 'Georgia' : 'System',
    lineHeight: fontSize * 1.8,
    letterSpacing: 0.2,
  },
  listenBar: {
    backgroundColor: theme.surface,
    borderTopWidth: 1,
    borderTopColor: theme.border,
    paddingTop: 12,
    paddingBottom: 8,
    paddingHorizontal: 16,
  },
  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: theme.border,
    backgroundColor: theme.surface,
    gap: 8,
  },
  pageBtn: {
    padding: 8,
  },
  pageBtnText: {
    fontSize: 28,
    color: theme.text,
    lineHeight: 32,
  },
  disabled: {
    opacity: 0.3,
  },
  progressSection: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  pageLabel: {
    fontSize: 13,
    color: theme.textSecondary,
    fontWeight: '500',
  },
  progressTrack: {
    width: '100%',
    height: 3,
    backgroundColor: theme.border,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: theme.accent,
    borderRadius: 2,
  },
  listenBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: theme.accent,
  },
  listenBtnActive: {
    backgroundColor: theme.accent,
  },
  listenBtnText: {
    fontSize: 13,
    color: theme.accent,
    fontWeight: '600',
  },
});
