/**
 * textSplitter.js
 * Splits raw extracted PDF text into chapters and readable pages.
 */

const WORDS_PER_PAGE = 250; // ~250 words per screen "page"

const CHAPTER_PATTERNS = [
  /^(chapter\s+\d+|chapter\s+[ivxlcdm]+)/i,
  /^(part\s+\d+|part\s+[ivxlcdm]+)/i,
  /^(section\s+\d+)/i,
  /^\d+\.\s+[A-Z]/,
  /^[A-Z][A-Z\s]{5,}$/, // ALL CAPS headings
];

/**
 * Detect if a paragraph is a chapter/section heading
 */
function isHeading(paragraph) {
  const trimmed = paragraph.trim();
  if (trimmed.length > 120) return false; // Too long to be a heading
  return CHAPTER_PATTERNS.some(pattern => pattern.test(trimmed));
}

/**
 * Split text into paragraphs
 */
function splitIntoParagraphs(text) {
  return text
    .split(/\n\s*\n/)
    .map(p => p.replace(/\s+/g, ' ').trim())
    .filter(p => p.length > 0);
}

/**
 * Split text into chapters based on heading detection
 */
export function detectChapters(text) {
  const paragraphs = splitIntoParagraphs(text);
  const chapters = [];
  let current = { title: 'Introduction', paragraphs: [] };

  for (const para of paragraphs) {
    if (isHeading(para)) {
      if (current.paragraphs.length > 0) {
        chapters.push(current);
      }
      current = { title: para.trim(), paragraphs: [] };
    } else {
      current.paragraphs.push(para);
    }
  }

  if (current.paragraphs.length > 0) {
    chapters.push(current);
  }

  // If no chapters detected, treat entire text as one chapter
  if (chapters.length === 0) {
    return [{ title: 'Content', paragraphs }];
  }

  return chapters;
}

/**
 * Split a chapter's paragraphs into screen pages.
 * Each page contains roughly WORDS_PER_PAGE words.
 */
export function splitChapterIntoPages(chapter) {
  const pages = [];
  let currentPage = [];
  let wordCount = 0;

  for (const para of chapter.paragraphs) {
    const words = para.split(/\s+/).length;

    if (wordCount + words > WORDS_PER_PAGE && currentPage.length > 0) {
      pages.push(currentPage.join('\n\n'));
      currentPage = [para];
      wordCount = words;
    } else {
      currentPage.push(para);
      wordCount += words;
    }
  }

  if (currentPage.length > 0) {
    pages.push(currentPage.join('\n\n'));
  }

  return pages.length > 0 ? pages : [''];
}

/**
 * Master function: takes raw text, returns flat array of page strings
 * and chapter metadata.
 */
export function processText(text) {
  const chapters = detectChapters(text);
  const allPages = [];
  const chapterMap = []; // { title, startPage, endPage }

  for (const chapter of chapters) {
    const pages = splitChapterIntoPages(chapter);
    const startPage = allPages.length;
    allPages.push(...pages.map((content, i) => ({
      content,
      chapterTitle: chapter.title,
      chapterIndex: chapterMap.length,
      pageInChapter: i,
    })));
    chapterMap.push({
      title: chapter.title,
      startPage,
      endPage: allPages.length - 1,
    });
  }

  return {
    pages: allPages,
    chapters: chapterMap,
    totalPages: allPages.length,
  };
}

/**
 * Split page content into individual sentences for TTS highlighting
 */
export function splitIntoSentences(text) {
  // Split on sentence-ending punctuation, keeping the punctuation
  const raw = text.split(/(?<=[.!?])\s+/);
  return raw
    .map(s => s.trim())
    .filter(s => s.length > 0);
}
