import React from 'react';
import {
  View, Text, StyleSheet, SafeAreaView,
  TouchableOpacity, ScrollView,
} from 'react-native';
import { useAppContext } from '../context/AppContext';

const SPEED_OPTIONS = [
  { label: '0.75×', value: 0.75 },
  { label: '1×', value: 1.0 },
  { label: '1.25×', value: 1.25 },
  { label: '1.5×', value: 1.5 },
  { label: '2×', value: 2.0 },
];

const FONT_SIZE_OPTIONS = [
  { label: 'Small', value: 'small' },
  { label: 'Medium', value: 'medium' },
  { label: 'Large', value: 'large' },
];

const FONT_FAMILY_OPTIONS = [
  { label: 'Serif', value: 'serif' },
  { label: 'Sans', value: 'sans' },
];

const THEME_OPTIONS = [
  { label: '☀️ Light', value: 'light' },
  { label: '🌙 Dark', value: 'dark' },
  { label: '📜 Sepia', value: 'sepia' },
];

function OptionGroup({ label, options, currentValue, onSelect, theme }) {
  const s = groupStyles(theme);
  return (
    <View style={s.group}>
      <Text style={s.label}>{label}</Text>
      <View style={s.options}>
        {options.map(opt => (
          <TouchableOpacity
            key={String(opt.value)}
            style={[s.option, currentValue === opt.value && s.optionActive]}
            onPress={() => onSelect(opt.value)}
            activeOpacity={0.7}
          >
            <Text style={[s.optionText, currentValue === opt.value && s.optionTextActive]}>
              {opt.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const groupStyles = (theme) => StyleSheet.create({
  group: { marginBottom: 28 },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 10,
  },
  options: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  option: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 24,
    borderWidth: 1.5,
    borderColor: theme.border,
    backgroundColor: theme.surface,
  },
  optionActive: {
    borderColor: theme.accent,
    backgroundColor: theme.accentLight,
  },
  optionText: {
    fontSize: 15,
    color: theme.textSecondary,
    fontWeight: '500',
  },
  optionTextActive: {
    color: theme.accent,
    fontWeight: '600',
  },
});

export default function SettingsScreen() {
  const { theme, settings, updateSettings } = useAppContext();
  const s = styles(theme);

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <Text style={s.title}>Settings</Text>
      </View>
      <ScrollView
        style={s.scroll}
        contentContainerStyle={s.content}
        showsVerticalScrollIndicator={false}
      >
        <OptionGroup
          label="Theme"
          options={THEME_OPTIONS}
          currentValue={settings.theme}
          onSelect={(v) => updateSettings({ theme: v })}
          theme={theme}
        />
        <OptionGroup
          label="Font Size"
          options={FONT_SIZE_OPTIONS}
          currentValue={settings.fontSize}
          onSelect={(v) => updateSettings({ fontSize: v })}
          theme={theme}
        />
        <OptionGroup
          label="Font Family"
          options={FONT_FAMILY_OPTIONS}
          currentValue={settings.fontFamily}
          onSelect={(v) => updateSettings({ fontFamily: v })}
          theme={theme}
        />
        <OptionGroup
          label="Narration Speed"
          options={SPEED_OPTIONS}
          currentValue={settings.ttsSpeed}
          onSelect={(v) => updateSettings({ ttsSpeed: v })}
          theme={theme}
        />

        <View style={s.footer}>
          <Text style={s.footerText}>BookCast v1.0.0</Text>
          <Text style={s.footerSub}>Your PDF reading companion</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = (theme) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.background },
  header: {
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.text,
    fontFamily: 'Georgia',
  },
  scroll: { flex: 1 },
  content: { padding: 24, paddingBottom: 48 },
  footer: { alignItems: 'center', marginTop: 32 },
  footerText: {
    fontSize: 14,
    color: theme.textSecondary,
    fontWeight: '500',
  },
  footerSub: {
    fontSize: 12,
    color: theme.textSecondary,
    marginTop: 2,
  },
});
