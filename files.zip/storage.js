import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  BOOKS: '@bookcast_books',
  BOOKMARKS: '@bookcast_bookmarks',
  SETTINGS: '@bookcast_settings',
};

// ── Settings ──────────────────────────────────────────────
export async function getSettings() {
  try {
    const raw = await AsyncStorage.getItem(KEYS.SETTINGS);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export async function saveSettings(settings) {
  try {
    await AsyncStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) { console.error('saveSettings', e); }
}

// ── Books ─────────────────────────────────────────────────
export async function getBooks() {
  try {
    const raw = await AsyncStorage.getItem(KEYS.BOOKS);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export async function saveBooks(books) {
  try {
    await AsyncStorage.setItem(KEYS.BOOKS, JSON.stringify(books));
  } catch (e) { console.error('saveBooks', e); }
}

export async function saveBook(book) {
  const books = await getBooks();
  const idx = books.findIndex(b => b.id === book.id);
  if (idx >= 0) books[idx] = book;
  else books.unshift(book);
  await saveBooks(books);
  return books;
}

export async function updateBookProgress(bookId, currentPage) {
  const books = await getBooks();
  const idx = books.findIndex(b => b.id === bookId);
  if (idx >= 0) {
    books[idx].currentPage = currentPage;
    books[idx].progress = Math.round((currentPage / books[idx].totalPages) * 100);
    books[idx].lastOpened = new Date().toISOString();
    await saveBooks(books);
  }
  return books;
}

export async function deleteBook(bookId) {
  const books = await getBooks();
  const next = books.filter(b => b.id !== bookId);
  await saveBooks(next);
  return next;
}

// ── Bookmarks ─────────────────────────────────────────────
export async function getBookmarks() {
  try {
    const raw = await AsyncStorage.getItem(KEYS.BOOKMARKS);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export async function saveBookmark(bookmark) {
  const marks = await getBookmarks();
  marks.unshift(bookmark);
  await AsyncStorage.setItem(KEYS.BOOKMARKS, JSON.stringify(marks));
  return marks;
}

export async function deleteBookmark(bookmarkId) {
  const marks = await getBookmarks();
  const next = marks.filter(m => m.id !== bookmarkId);
  await AsyncStorage.setItem(KEYS.BOOKMARKS, JSON.stringify(next));
  return next;
}
