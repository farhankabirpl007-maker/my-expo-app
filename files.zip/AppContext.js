import React, { createContext, useContext, useState, useEffect } from 'react';
import { getSettings, getBooks, saveSettings } from '../utils/storage';

const THEMES = {
  light: {
    id: 'light',
    background: '#FDFCF8',
    surface: '#F5F3EE',
    text: '#1A1A1A',
    textSecondary: '#6B6B6B',
    accent: '#2D6A4F',
    accentLight: '#E8F4EE',
    border: '#E0DDD5',
    highlight: '#FFE066',
    card: '#FFFFFF',
    statusBar: 'dark',
    shadow: 'rgba(0,0,0,0.08)',
  },
  dark: {
    id: 'dark',
    background: '#1A1A1A',
    surface: '#242424',
    text: '#E8E4D9',
    textSecondary: '#9A9590',
    accent: '#52B788',
    accentLight: '#1E3A2E',
    border: '#333333',
    highlight: '#7B6914',
    card: '#2C2C2C',
    statusBar: 'light',
    shadow: 'rgba(0,0,0,0.3)',
  },
  sepia: {
    id: 'sepia',
    background: '#F4ECD8',
    surface: '#EDE0C4',
    text: '#3B2F2F',
    textSecondary: '#7A6350',
    accent: '#8B5E3C',
    accentLight: '#F5E6D3',
    border: '#D4C5A9',
    highlight: '#E8C84A',
    card: '#F9F3E8',
    statusBar: 'dark',
    shadow: 'rgba(59,47,47,0.1)',
  },
};

const FONT_SIZES = { small: 16, medium: 18, large: 20 };

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [settings, setSettings] = useState({
    theme: 'light',
    fontSize: 'medium',
    fontFamily: 'serif',
    ttsSpeed: 1.0,
  });
  const [books, setBooks] = useState([]);
  const [bookmarks, setBookmarks] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    async function init() {
      const s = await getSettings();
      if (s) setSettings(s);
      const b = await getBooks();
      if (b) setBooks(b);
      setLoaded(true);
    }
    init();
  }, []);

  const updateSettings = async (updates) => {
    const next = { ...settings, ...updates };
    setSettings(next);
    await saveSettings(next);
  };

  const theme = THEMES[settings.theme] || THEMES.light;
  const fontSize = FONT_SIZES[settings.fontSize] || 18;
  const fontFamily = settings.fontFamily === 'serif' ? 'Georgia' : 'System';

  return (
    <AppContext.Provider
      value={{
        settings,
        updateSettings,
        theme,
        fontSize,
        fontFamily,
        books,
        setBooks,
        bookmarks,
        setBookmarks,
        loaded,
        THEMES,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}
