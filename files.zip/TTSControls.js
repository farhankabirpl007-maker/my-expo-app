import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const SPEEDS = [0.75, 1.0, 1.25, 1.5, 2.0];

export default function TTSControls({
  isPlaying,
  speed,
  onPlayPause,
  onPrev,
  onNext,
  onSpeedChange,
  theme,
}) {
  const s = styles(theme);

  const nextSpeed = () => {
    const idx = SPEEDS.indexOf(speed);
    const next = SPEEDS[(idx + 1) % SPEEDS.length];
    onSpeedChange(next);
  };

  return (
    <View style={s.container}>
      {/* Sentence controls */}
      <View style={s.controls}>
        <TouchableOpacity onPress={onPrev} style={s.controlBtn}>
          <Text style={s.controlIcon}>⏮</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={onPlayPause} style={s.playBtn}>
          <Text style={s.playIcon}>{isPlaying ? '⏸' : '▶'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={onNext} style={s.controlBtn}>
          <Text style={s.controlIcon}>⏭</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={nextSpeed} style={s.speedBtn}>
          <Text style={s.speedText}>{speed}×</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = (theme) => StyleSheet.create({
  container: {
    paddingVertical: 4,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
  },
  controlBtn: {
    padding: 8,
  },
  controlIcon: {
    fontSize: 22,
    color: theme.text,
  },
  playBtn: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: theme.accent,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: theme.accent,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  playIcon: {
    fontSize: 22,
    color: '#FFFFFF',
  },
  speedBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: theme.border,
    backgroundColor: theme.surface,
  },
  speedText: {
    fontSize: 13,
    fontWeight: '700',
    color: theme.text,
  },
});
