import React, { useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, SafeAreaView, Alert,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import { useAppContext } from '../context/AppContext';
import { getBookmarks, deleteBookmark } from '../utils/storage';

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function BookmarksScreen({ navigation }) {
  const { theme, bookmarks, setBookmarks, books } = useAppContext();

  useFocusEffect(
    useCallback(() => {
      getBookmarks().then(setBookmarks);
    }, [])
  );

  const handleDelete = (id) => {
    Alert.alert('Delete Bookmark', 'Remove this bookmark?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive', onPress: async () => {
          const updated = await deleteBookmark(id);
          setBookmarks(updated);
        }
      }
    ]);
  };

  const handleJump = (bookmark) => {
    const book = books.find(b => b.id === bookmark.bookId);
    if (!book) {
      Alert.alert('Book not found', 'The original book is no longer in your library.');
      return;
    }
    navigation.navigate('Reader', { book: { ...book, currentPage: bookmark.pageNumber } });
  };

  const s = styles(theme);

  const EmptyState = () => (
    <View style={s.emptyContainer}>
      <Text style={s.emptyEmoji}>🔖</Text>
      <Text style={s.emptyTitle}>No bookmarks yet</Text>
      <Text style={s.emptySubtitle}>
        While reading, tap the bookmark icon to save important pages
      </Text>
    </View>
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={s.card}
      onPress={() => handleJump(item)}
      onLongPress={() => handleDelete(item.id)}
      activeOpacity={0.75}
    >
      <View style={s.cardHeader}>
        <View style={s.dot} />
        <Text style={s.bookTitle} numberOfLines={1}>{item.bookTitle}</Text>
        <Text style={s.pageNum}>p. {item.pageNumber + 1}</Text>
      </View>
      <Text style={s.snippet} numberOfLines={3}>{item.text}</Text>
      <Text style={s.date}>{formatDate(item.createdAt)}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <Text style={s.title}>Bookmarks</Text>
        <Text style={s.count}>{bookmarks.length} saved</Text>
      </View>
      <FlatList
        data={bookmarks}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        ListEmptyComponent={<EmptyState />}
        contentContainerStyle={bookmarks.length === 0 ? s.emptyList : s.list}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = (theme) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.background },
  header: {
    flexDirection: 'row',
    alignItems: 'baseline',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
    gap: 8,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.text,
    fontFamily: 'Georgia',
  },
  count: {
    fontSize: 14,
    color: theme.textSecondary,
  },
  list: { padding: 16 },
  emptyList: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyEmoji: { fontSize: 56, marginBottom: 16 },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: theme.text,
    fontFamily: 'Georgia',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 15,
    color: theme.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  card: {
    backgroundColor: theme.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: theme.border,
    shadowColor: theme.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.accent,
  },
  bookTitle: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
    color: theme.accent,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  pageNum: {
    fontSize: 12,
    color: theme.textSecondary,
    fontWeight: '500',
  },
  snippet: {
    fontSize: 15,
    color: theme.text,
    fontFamily: 'Georgia',
    lineHeight: 24,
    marginBottom: 8,
  },
  date: {
    fontSize: 12,
    color: theme.textSecondary,
  },
});
