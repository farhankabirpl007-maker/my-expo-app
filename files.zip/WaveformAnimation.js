import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet } from 'react-native';

const BAR_COUNT = 5;
const BAR_HEIGHTS = [14, 22, 30, 22, 14];
const ANIMATION_DURATIONS = [400, 300, 350, 450, 320];

export default function WaveformAnimation({ isPlaying, theme }) {
  const animations = useRef(
    Array.from({ length: BAR_COUNT }, (_, i) => new Animated.Value(BAR_HEIGHTS[i]))
  ).current;

  useEffect(() => {
    if (isPlaying) {
      const anims = animations.map((anim, i) =>
        Animated.loop(
          Animated.sequence([
            Animated.timing(anim, {
              toValue: BAR_HEIGHTS[i] * 0.3,
              duration: ANIMATION_DURATIONS[i],
              useNativeDriver: false,
            }),
            Animated.timing(anim, {
              toValue: BAR_HEIGHTS[i],
              duration: ANIMATION_DURATIONS[i],
              useNativeDriver: false,
            }),
          ])
        )
      );
      anims.forEach(a => a.start());
      return () => anims.forEach(a => a.stop());
    } else {
      animations.forEach((anim, i) => {
        Animated.timing(anim, {
          toValue: BAR_HEIGHTS[i] * 0.3,
          duration: 200,
          useNativeDriver: false,
        }).start();
      });
    }
  }, [isPlaying]);

  const s = styles(theme);

  return (
    <View style={s.container}>
      {animations.map((anim, i) => (
        <Animated.View
          key={i}
          style={[
            s.bar,
            {
              height: anim,
              backgroundColor: isPlaying ? theme.accent : theme.border,
            },
          ]}
        />
      ))}
    </View>
  );
}

const styles = (theme) => StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    height: 36,
    marginBottom: 8,
  },
  bar: {
    width: 4,
    borderRadius: 2,
  },
});
