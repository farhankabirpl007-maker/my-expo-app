import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function SentenceHighlighter({
  sentences,
  currentIndex,
  theme,
  fontSize,
  fontFamily,
}) {
  const s = styles(theme, fontSize, fontFamily);

  return (
    <View style={s.container}>
      <Text style={s.text}>
        {sentences.map((sentence, i) => (
          <Text key={i}>
            <Text
              style={[
                s.sentence,
                i === currentIndex && s.highlighted,
                i < currentIndex && s.spoken,
              ]}
            >
              {sentence}
            </Text>
            <Text style={s.sentence}>{' '}</Text>
          </Text>
        ))}
      </Text>
    </View>
  );
}

const styles = (theme, fontSize, fontFamily) => StyleSheet.create({
  container: {
    paddingBottom: 20,
  },
  text: {
    fontSize,
    color: theme.text,
    fontFamily: fontFamily === 'Georgia' ? 'Georgia' : 'System',
    lineHeight: fontSize * 1.9,
  },
  sentence: {
    color: theme.text,
  },
  highlighted: {
    backgroundColor: theme.highlight,
    color: theme.id === 'dark' ? '#1A1A1A' : theme.text,
    borderRadius: 3,
  },
  spoken: {
    color: theme.textSecondary,
  },
});
