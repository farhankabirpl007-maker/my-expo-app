import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function PageView({ content, theme, fontSize, fontFamily, scrollRef }) {
  const s = styles(theme, fontSize, fontFamily);
  return (
    <ScrollView
      ref={scrollRef}
      style={s.scroll}
      contentContainerStyle={s.content}
      showsVerticalScrollIndicator={false}
    >
      <Text style={s.text}>{content}</Text>
    </ScrollView>
  );
}

const styles = (theme, fontSize, fontFamily) => StyleSheet.create({
  scroll: { flex: 1, backgroundColor: theme.background },
  content: { padding: 24, paddingBottom: 48 },
  text: {
    fontSize,
    color: theme.text,
    fontFamily: fontFamily === 'serif' ? 'Georgia' : 'System',
    lineHeight: fontSize * 1.8,
    letterSpacing: 0.2,
  },
});
