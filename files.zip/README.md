# 📚 BookCast — PDF Reading & Listening App

A clean, minimal Expo app that lets you read and listen to any PDF on your phone.

## Features
- 📂 Open any PDF from your device
- 📖 Clean book-like reading experience with paged text
- 🎧 Text-to-speech with live sentence highlighting
- 🔖 Bookmark important pages
- 🌙 Light / Dark / Sepia themes
- ⚙️ Adjustable font size, family, and TTS speed

---

## Getting Started

### 1. Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- Expo Go app on your iOS/Android device

### 2. Install dependencies
```bash
cd BookCast
npm install
```

### 3. Start the development server
```bash
npx expo start
```

Scan the QR code with Expo Go on your phone.

---

## Project Structure

```
BookCast/
├── App.js                        # Root navigator setup
├── app.json                      # Expo configuration
├── babel.config.js
├── package.json
└── src/
    ├── context/
    │   └── AppContext.js         # Global state (theme, settings, books)
    ├── screens/
    │   ├── HomeScreen.js         # Library view + PDF picker
    │   ├── ReaderScreen.js       # Reading + Listen mode
    │   ├── BookmarksScreen.js    # Saved bookmarks
    │   └── SettingsScreen.js     # Theme, font, TTS settings
    ├── components/
    │   ├── BookCard.js           # Book list card
    │   ├── PageView.js           # Page content display
    │   ├── TTSControls.js        # Play/pause/speed controls
    │   ├── SentenceHighlighter.js # TTS sentence highlighting
    │   └── WaveformAnimation.js  # Audio playing animation
    └── utils/
        ├── pdfExtractor.js       # PDF text extraction
        ├── textSplitter.js       # Text → pages/chapters
        └── storage.js            # AsyncStorage helpers
```

---

## PDF Compatibility

BookCast works best with **text-based PDFs** (not scanned images):

✅ Works great:
- Ebooks (novels, non-fiction)
- Academic papers
- Exported Word/Google Docs
- Project Gutenberg PDFs

⚠️ Limited support:
- Scanned/image PDFs → shows placeholder content
- Encrypted PDFs
- PDFs with complex layouts (tables, columns)

---

## Architecture Notes

### PDF Extraction
`pdfExtractor.js` implements a lightweight binary PDF parser that:
1. Reads the raw PDF file as base64
2. Extracts BT/ET (Begin Text / End Text) blocks
3. Parses `Tj` and `TJ` operators for text content
4. Decodes PDF string escape sequences
5. Cleans and normalizes the output

For production use, consider integrating `pdfjs-dist` via a WebView bridge for more robust extraction.

### Text Processing
`textSplitter.js` handles:
- Chapter detection via heading pattern matching
- Splitting text into ~250-word screen pages
- Sentence splitting for TTS highlighting

### TTS Architecture
`ReaderScreen.js` drives TTS using `expo-speech`:
- Plays one sentence at a time
- Tracks sentence index via a ref (not state) to avoid stale closure issues
- Highlights the current sentence in `SentenceHighlighter`
- Auto-advances to next page when a page finishes

---

## Customization

### Add more themes
In `AppContext.js`, extend the `THEMES` object:
```js
const THEMES = {
  // ...existing themes
  forest: {
    background: '#1B2A1E',
    text: '#D4E8D0',
    accent: '#6BCB77',
    // ...
  }
};
```

### Change words-per-page
In `textSplitter.js`:
```js
const WORDS_PER_PAGE = 300; // increase for longer pages
```

---

## Known Limitations

1. **PDF extraction** is basic — complex PDFs may not extract correctly
2. **TTS** uses the device's built-in speech engine — quality varies by OS
3. **No cloud sync** — books are stored locally only
4. **No page count from PDF** — page count is derived from extracted text

---

## Future Improvements

- [ ] WebView-based pdfjs-dist for better PDF parsing
- [ ] OCR support for scanned PDFs
- [ ] Cloud backup via iCloud/Google Drive
- [ ] Reading statistics and streaks
- [ ] Dictionary lookup on long press
- [ ] Export highlights to notes apps
