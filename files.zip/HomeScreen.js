import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  SafeAreaView, Alert, ActivityIndicator, Animated,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { useFocusEffect } from '@react-navigation/native';

import { useAppContext } from '../context/AppContext';
import BookCard from '../components/BookCard';
import { extractTextFromPDF } from '../utils/pdfExtractor';
import { processText } from '../utils/textSplitter';
import { saveBook, getBooks, getBookmarks } from '../utils/storage';

const CARD_COLORS = [
  '#2D6A4F', '#1B4332', '#40916C', '#52B788',
  '#8B5E3C', '#6D4C41', '#A0522D', '#5D4037',
  '#1565C0', '#283593', '#4527A0', '#6A1B9A',
];

function generateId() {
  return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
}

function getBookColor(id) {
  const idx = id.charCodeAt(0) % CARD_COLORS.length;
  return CARD_COLORS[idx];
}

export default function HomeScreen({ navigation }) {
  const { theme, books, setBooks, setBookmarks } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');

  useFocusEffect(
    useCallback(() => {
      async function loadData() {
        const b = await getBooks();
        setBooks(b);
        const bm = await getBookmarks();
        setBookmarks(bm);
      }
      loadData();
    }, [])
  );

  const handleOpenPDF = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
        copyToCacheDirectory: true,
      });

      if (result.canceled || !result.assets?.[0]) return;

      const file = result.assets[0];
      setLoading(true);
      setLoadingText('Reading PDF…');

      const { text, pageCount, isPlaceholder } = await extractTextFromPDF(file.uri);

      setLoadingText('Processing text…');
      const { pages, chapters, totalPages } = processText(text);

      const bookId = generateId();
      const book = {
        id: bookId,
        title: file.name.replace(/\.pdf$/i, ''),
        filePath: file.uri,
        extractedText: text,
        pages,
        chapters,
        totalPages,
        currentPage: 0,
        progress: 0,
        lastOpened: new Date().toISOString(),
        color: getBookColor(bookId),
        isPlaceholder,
      };

      setLoadingText('Saving…');
      const updatedBooks = await saveBook(book);
      setBooks(updatedBooks);
      setLoading(false);

      if (isPlaceholder) {
        Alert.alert(
          'Limited Extraction',
          "This PDF's text couldn't be fully extracted (it may be image-based or encrypted). Sample content is shown for demo purposes.",
          [{ text: 'OK', onPress: () => navigation.navigate('Reader', { book }) }]
        );
      } else {
        navigation.navigate('Reader', { book });
      }
    } catch (error) {
      setLoading(false);
      Alert.alert('Error', 'Could not open this PDF. Please try another file.');
      console.error(error);
    }
  };

  const handleBookPress = (book) => {
    navigation.navigate('Reader', { book });
  };

  const s = styles(theme);

  const EmptyState = () => (
    <View style={s.emptyContainer}>
      <Text style={s.emptyEmoji}>📚</Text>
      <Text style={s.emptyTitle}>Your library is empty</Text>
      <Text style={s.emptySubtitle}>
        Tap the button below to open your first PDF and start reading or listening
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <Text style={s.appName}>BookCast</Text>
        <Text style={s.subtitle}>Your PDF reading companion</Text>
      </View>

      {loading && (
        <View style={s.loadingOverlay}>
          <View style={s.loadingCard}>
            <ActivityIndicator size="large" color={theme.accent} />
            <Text style={s.loadingText}>{loadingText}</Text>
          </View>
        </View>
      )}

      <FlatList
        data={books}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <BookCard book={item} theme={theme} onPress={() => handleBookPress(item)} />
        )}
        ListEmptyComponent={<EmptyState />}
        contentContainerStyle={books.length === 0 ? s.emptyList : s.list}
        showsVerticalScrollIndicator={false}
      />

      <TouchableOpacity style={s.fab} onPress={handleOpenPDF} activeOpacity={0.85}>
        <Text style={s.fabIcon}>+</Text>
        <Text style={s.fabText}>Open PDF</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = (theme) => StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
  },
  appName: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.accent,
    fontFamily: 'Georgia',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    color: theme.textSecondary,
    marginTop: 2,
  },
  list: {
    padding: 16,
    paddingBottom: 100,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 80,
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
  },
  emptyEmoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: theme.text,
    fontFamily: 'Georgia',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 15,
    color: theme.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 20,
    left: 20,
    backgroundColor: theme.accent,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 16,
    paddingVertical: 16,
    shadowColor: theme.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 8,
  },
  fabIcon: {
    fontSize: 22,
    color: '#FFFFFF',
    fontWeight: '600',
    marginRight: 8,
  },
  fabText: {
    fontSize: 17,
    color: '#FFFFFF',
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 100,
  },
  loadingCard: {
    backgroundColor: theme.card,
    borderRadius: 20,
    padding: 32,
    alignItems: 'center',
    gap: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 10,
  },
  loadingText: {
    fontSize: 16,
    color: theme.text,
    fontWeight: '500',
  },
});
