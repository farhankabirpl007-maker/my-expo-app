import * as FileSystem from 'expo-file-system';

/**
 * Extracts text from a PDF file.
 * Strategy: Use pdfjs-dist (web-compatible) running in a JS context.
 * For React Native, we parse the PDF binary and extract text streams.
 *
 * Since full pdfjs-dist requires a browser context, we implement a
 * lightweight PDF text stream extractor that handles most text-based PDFs.
 */

/**
 * Read raw bytes from a PDF file
 */
async function readPDFBytes(fileUri) {
  const content = await FileSystem.readAsStringAsync(fileUri, {
    encoding: FileSystem.EncodingType.Base64,
  });
  return content;
}

/**
 * Decode base64 to a binary string
 */
function base64ToBinary(base64) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let result = '';
  let i = 0;
  base64 = base64.replace(/[^A-Za-z0-9+/]/g, '');
  while (i < base64.length) {
    const enc1 = chars.indexOf(base64[i++]);
    const enc2 = chars.indexOf(base64[i++]);
    const enc3 = chars.indexOf(base64[i++]);
    const enc4 = chars.indexOf(base64[i++]);
    const chr1 = (enc1 << 2) | (enc2 >> 4);
    const chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
    const chr3 = ((enc3 & 3) << 6) | enc4;
    result += String.fromCharCode(chr1);
    if (enc3 !== 64) result += String.fromCharCode(chr2);
    if (enc4 !== 64) result += String.fromCharCode(chr3);
  }
  return result;
}

/**
 * Extract readable text from PDF binary content.
 * Scans for BT (Begin Text) ... ET (End Text) blocks and extracts Tj/TJ operands.
 */
function extractTextFromPDFBinary(binaryStr) {
  const texts = [];

  // Find all text blocks between BT and ET
  const btEtRegex = /BT([\s\S]*?)ET/g;
  let match;

  while ((match = btEtRegex.exec(binaryStr)) !== null) {
    const block = match[1];

    // Extract Tj strings: (text) Tj
    const tjRegex = /\(([^)\\]*(?:\\.[^)\\]*)*)\)\s*Tj/g;
    let tjMatch;
    while ((tjMatch = tjRegex.exec(block)) !== null) {
      const text = decodePDFString(tjMatch[1]);
      if (text.trim()) texts.push(text);
    }

    // Extract TJ arrays: [(text) offset (text)] TJ
    const tjArrayRegex = /\[([\s\S]*?)\]\s*TJ/g;
    let tjArrMatch;
    while ((tjArrMatch = tjArrayRegex.exec(block)) !== null) {
      const arrContent = tjArrMatch[1];
      const strRegex = /\(([^)\\]*(?:\\.[^)\\]*)*)\)/g;
      let strMatch;
      let pageText = '';
      while ((strMatch = strRegex.exec(arrContent)) !== null) {
        pageText += decodePDFString(strMatch[1]);
      }
      if (pageText.trim()) texts.push(pageText);
    }
  }

  return texts;
}

/**
 * Decode PDF string escape sequences
 */
function decodePDFString(str) {
  return str
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\t/g, '\t')
    .replace(/\\b/g, '\b')
    .replace(/\\f/g, '\f')
    .replace(/\\\(/g, '(')
    .replace(/\\\)/g, ')')
    .replace(/\\\\/g, '\\')
    .replace(/\\(\d{3})/g, (_, oct) => String.fromCharCode(parseInt(oct, 8)));
}

/**
 * Clean and normalize extracted text
 */
function cleanText(texts) {
  let combined = texts.join(' ');

  // Remove excessive whitespace
  combined = combined
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/^\s+|\s+$/g, '');

  // Filter out likely garbage (non-printable, too short)
  const lines = combined.split('\n').filter(line => {
    const trimmed = line.trim();
    if (trimmed.length < 2) return false;
    // Filter lines that are mostly non-alphabetic (binary garbage)
    const alphaRatio = (trimmed.match(/[a-zA-Z ]/g) || []).length / trimmed.length;
    return alphaRatio > 0.3;
  });

  return lines.join('\n');
}

/**
 * Main PDF extraction function
 * @param {string} fileUri - URI of the PDF file
 * @returns {Promise<{text: string, pageCount: number}>}
 */
export async function extractTextFromPDF(fileUri) {
  try {
    const base64 = await readPDFBytes(fileUri);
    const binary = base64ToBinary(base64);

    // Count pages (rough estimate from /Page objects)
    const pageMatches = binary.match(/\/Type\s*\/Page[^s]/g);
    const pageCount = pageMatches ? pageMatches.length : 1;

    // Extract text
    const rawTexts = extractTextFromPDFBinary(binary);
    const text = cleanText(rawTexts);

    if (!text || text.length < 50) {
      // Fallback: return placeholder text for testing
      return {
        text: generateSampleText(),
        pageCount: Math.max(pageCount, 5),
        isPlaceholder: true,
      };
    }

    return { text, pageCount, isPlaceholder: false };
  } catch (error) {
    console.error('PDF extraction error:', error);
    return {
      text: generateSampleText(),
      pageCount: 10,
      isPlaceholder: true,
    };
  }
}

/**
 * Generate sample text for PDFs that can't be extracted
 * (encrypted, image-only, or complex formatting)
 */
function generateSampleText() {
  return `Chapter 1: The Beginning

This PDF contains content that couldn't be extracted as plain text. This may be because the PDF uses image-based scanning, custom encoding, or encryption.

To get the best experience with BookCast, please use text-based PDFs. You can convert scanned PDFs to text-searchable PDFs using tools like Adobe Acrobat or online OCR services.

Chapter 2: Getting Started

BookCast works best with:
- Novels and fiction books in PDF format
- Academic papers and essays
- Reports and documents with selectable text
- Ebooks exported as PDF

Chapter 3: Features

BookCast offers a complete reading and listening experience. You can read at your own pace, or let the text-to-speech engine narrate the content for you while highlighting each sentence as it's spoken.

Adjust the reading speed, font size, and color theme to suit your preferences. Bookmark important passages to return to them later.

Chapter 4: Tips for Best Results

For the best reading experience, choose PDFs that were created digitally rather than scanned from physical books. Digital PDFs preserve the text structure, making it easier to extract and reformat the content.

You can find text-based PDFs from sources like Project Gutenberg, which offers thousands of free public domain books in various formats including PDF.`;
}
